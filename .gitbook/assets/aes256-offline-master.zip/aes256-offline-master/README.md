# aes256-offline
An HTML+JS application that encrypts input data with AES-256-CBC algorithm offline without the need of a server-side script
